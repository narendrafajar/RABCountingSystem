@section('pagetitle', __('Dashboard'))
<x-app-layout>

</x-app-layout>