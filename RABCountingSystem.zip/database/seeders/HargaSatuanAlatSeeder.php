<?php

namespace Database\Seeders;


use Maatwebsite\Excel\Facades\Excel;
use App\Models\HargaSatuanAlat;
use DB;
use App\Imports\HargaSatuanAlatImport;
use Illuminate\Database\Seeder;

class HargaSatuanAlatSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $excelFile = storage_path('app/excel/harga_satuan_alat.xlsx');
        $excelData = Excel::toCollection(new HargaSatuanAlatImport(), $excelFile)->first();
        foreach ($excelData as $row) {
            HargaSatuanAlat::create([
            'kode' => $row[1], // Sesuaikan dengan indeks kolom satuan di file Excel
            'nama' => $row[2], // Sesuaikan dengan indeks kolom satuan di file Excel
            'satuan' =>$row[3], // Sesuaikan dengan indeks kolom satuan di file Excel
            'harga' =>$row[4], // Sesuaikan dengan indeks kolom satuan di file Excel
                // Tambahkan kolom sesuai dengan struktur tabel Anda
            ]);
        }
    }
}
