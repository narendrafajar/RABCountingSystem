<nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex align-items-top flex-row">
    <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-start">
        <div class="me-3">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-bs-toggle="minimize">
            <span class="icon-menu"></span>
        </button>
        </div>
        <div>
        <a class="navbar-brand brand-logo" href="#">
            <img src="<?php echo e(asset('images/RCS_logo.png')); ?>" alt="logo" />
        </a>
        <a class="navbar-brand brand-logo-mini" href="#">
            <img src="<?php echo e(asset('images/fav_icon_rcs.png')); ?>" alt="logo" />
        </a>
        </div>
    </div>
    <div class="navbar-menu-wrapper d-flex align-items-top"> 
        <ul class="navbar-nav">
        <li class="nav-item font-weight-semibold d-none d-lg-block ms-0">
            <h1 class="welcome-text"><span id="ucapan"></span>, <span class="text-black fw-bold"><?php echo e(Auth::user()->name); ?></span></h1>
            <h3 class="welcome-sub-text"><?php echo $__env->yieldContent('pagetitle'); ?></h3>
        </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-bs-toggle="offcanvas">
        <span class="mdi mdi-menu"></span>
        </button>
    </div>
    </nav>
    <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
              <i class="mdi mdi-grid-large menu-icon"></i>
              <span class="menu-title"><?php echo e(__('Dashboard')); ?></span>
            </a>
          </li>
          <li class="nav-item nav-category"><?php echo e(__('Main Menu')); ?></li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('proyek_index')); ?>">
              <i class="mdi mdi-briefcase menu-icon"></i>
              <span class="menu-title"><?php echo e(__('Daftar Proyek')); ?></span>
            </a>
          </li>
          <li class="nav-item nav-category"><?php echo e(__('Pengaturan')); ?></li>
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
              <i class="menu-icon mdi mdi-settings"></i>
                <span class="menu-title"><?php echo e(__('Pengaturan Analisa')); ?></span>
              <i class="menu-arrow"></i> 
            </a>
            <div class="collapse" id="ui-basic">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('proyek_index')); ?>"><?php echo e(__('Bahan')); ?></a></li>
                <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('proyek_index')); ?>"><?php echo e(__('Jenis Bahan')); ?></a></li>
                <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('hsa_index')); ?>"><?php echo e(__('Harga Satuan Alat')); ?></a></li>
                <li class="nav-item"> <a class="nav-link" href="<?php echo e(route('proyek_index')); ?>"><?php echo e(__('Harga Satuan Pekerja')); ?></a></li>
              </ul>
            </div>
          </li>
        </ul>
        <ul class="nav">
          <li class="nav-item">
            <form method="POST" action="<?php echo e(route('logout')); ?>">
              <?php echo csrf_field(); ?>
              <button type="submit" class="nav-link">
                <i class="mdi mdi-camera-timer menu-icon"></i> 
                <span class="menu-title"><?php echo e(__('Keluar')); ?></span>
              </button>
            </form>
          </li>
        </ul>
      </nav><?php /**PATH C:\Users\LENOVO\Documents\GitHub\RABCountingSystem\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>