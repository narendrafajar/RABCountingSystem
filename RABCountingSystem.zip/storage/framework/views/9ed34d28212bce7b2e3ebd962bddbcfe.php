<p class="m-0 text-muted"><?php echo app('translator')->get('pagination.showing'); ?> <span><?php echo e(((($paginator->currentPage() - 1) * $paginator->perPage())) + 1); ?></span> <?php echo app('translator')->get('pagination.to'); ?> <span><?php echo e((($paginator->currentPage() * $paginator->perPage()) - (floor($paginator->currentPage() / $paginator->lastPage()) * abs($paginator->total() - ($paginator->currentPage() * $paginator->perPage()))))); ?></span> <?php echo app('translator')->get('pagination.of'); ?> <span><?php echo e($paginator->total()); ?></span> <?php echo app('translator')->get('pagination.entries'); ?></p>
<ul class="pagination m-0 ms-auto">
    
    <?php if($paginator->onFirstPage()): ?>
        <li class="page-item disabled">
            <a class="page-link" href="#" tabindex="-1" aria-disabled="true">
				<!-- Download SVG icon from http://tabler-icons.io/i/chevron-left -->
				<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="15 6 9 12 15 18"></polyline></svg>
				<?php echo app('translator')->get('pagination.previous'); ?>
			</a>
        </li>
    <?php else: ?>
        <li class="page-item">
            <a class="page-link" href="#" onclick="loadTable(<?php echo e('"' . $tablename . '"' . ', ' . $paginator->currentPage() - 1); ?>)">
				<!-- Download SVG icon from http://tabler-icons.io/i/chevron-left -->
				<svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="15 6 9 12 15 18"></polyline></svg>
				<?php echo app('translator')->get('pagination.previous'); ?>
			</a>
        </li>
    <?php endif; ?>

    
    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <?php if(is_array($element)): ?>
            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page == $paginator->currentPage()): ?>
                    <li class="page-item active"><a class="page-link" href="#"><?php echo e($page); ?></a></li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <?php if($paginator->hasMorePages()): ?>
        <li class="page-item">
            <a class="page-link" href="#" onclick="loadTable( <?php echo e('"' . $tablename . '"' . ', ' . $paginator->currentPage() + 1); ?> )">
                <?php echo app('translator')->get('pagination.next'); ?> <!-- Download SVG icon from http://tabler-icons.io/i/chevron-right -->
                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><polyline points="9 6 15 12 9 18" /></svg>
            </a>
        </li>
    <?php else: ?>
        <li class="page-item disabled" aria-disabled="true">
            <a class="page-link" href="#">
              <?php echo app('translator')->get('pagination.next'); ?> <!-- Download SVG icon from http://tabler-icons.io/i/chevron-right -->
              <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><polyline points="9 6 15 12 9 18" /></svg>
            </a>
        </li>
    <?php endif; ?>
</ul><?php /**PATH C:\Users\LENOVO\Documents\GitHub\RABCountingSystem\resources\views/vendor/pagination/rcs-paginator.blade.php ENDPATH**/ ?>