<?php $__env->startSection('pagetitle', __('Harga Satuan Alat')); ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div id="message-alert"></div>
    <div class="col-sm-12 col-md-12 col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title"><?php echo e(__('Daftar Harga Satuan Alat')); ?></h4>
                <p class="card-description">
                    <code><?php echo e(__('Daftar untuk pengaturan harga satuan alat RAB')); ?></code>
                </p>
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-6">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><?php echo e(__('Cari')); ?></span>
                                </div>
                                <input type="text" class="form-control" aria-label="<?php echo e(__('Cari Kode, Nama')); ?>" id="search_<?php echo e($data['tables'][0]); ?>" name="search_<?php echo e($data['tables'][0]); ?>" placeholder="<?php echo e(__('Ketik Nama / Kode HSA')); ?>" onkeyup="loadTable('<?php echo e($data['tables'][0]); ?>')">
                            </div>
                        </div>
                    </div>
                </div>
                <div id="table-<?php echo e($data['tables'][0]); ?>">
                    <div class="table-responsive pt-3" id="<?php echo e($data['tables'][0]); ?>">
                        <table class="table table-bordered" id="<?php echo e($data['tables'][0]); ?>">
                            <thead>
                                <tr>
                                    <th class="text-center"><?php echo e(__('#')); ?></th>
                                    <th class="text-center"><?php echo e(__('Kode')); ?></th>
                                    <th class="text-center"><?php echo e(__('Nama')); ?></th>
                                    <th class="text-center"><?php echo e(__('Satuan')); ?></th>
                                    <th class="text-center"><?php echo e(__('Harga')); ?></th>
                                    <th class="text-center"><?php echo e(__('Update Terakhir')); ?></th>
                                    <th class="text-center"><?php echo e(__('Aksi')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(isset($data['main']) && count($data['main']) > 0): ?>
                                    <?php
                                        $nomor = 1;
                                    ?>
                                    <?php $__currentLoopData = $data['main']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($nomor++); ?></td>
                                            <td class="text-center"><?php echo e($value->kode); ?></td>
                                            <td><?php echo e($value->nama); ?></td>
                                            <td class="text-center"><?php echo e($value->satuan); ?></td>
                                            <td class="text-end"><?php echo e('Rp. '.number_format($value->harga,2)); ?></td>
                                            <td class="text-center"><?php echo e(date("d M Y",strtotime($value->updated_at))); ?></td>
                                            <td class="text-center">
                                                <div class="input-group-prepend">
                                                  <button class="btn btn-sm btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="mdi mdi-pencil"></span></button>
                                                      <div class="dropdown-menu">
                                                        <a class="dropdown-item" href="#">Action</a>
                                                        <a class="dropdown-item" href="#">Another action</a>
                                                        <a class="dropdown-item" href="#">Something else here</a>
                                                        <div role="separator" class="dropdown-divider"></div>
                                                        <a class="dropdown-item" href="#">Separated link</a>
                                                      </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                       <td colspan="6" class="text-center"><?php echo e(__('Data Tidak Ditemukan')); ?></td> 
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if(isset($data['main']) && count($data['main']) > 0): ?>
                    <div class="card-footer d-flex align-items-center">
                        <?php echo e($data['main']->links('vendor.pagination.rcs-paginator', ['tablename' => $data['tables'][0]])); ?>

                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\LENOVO\Documents\GitHub\RABCountingSystem\resources\views/setting/harga-satuan-alat.blade.php ENDPATH**/ ?>