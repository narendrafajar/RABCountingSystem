<div id="table-<?php echo e($data['tables'][0]); ?>">
    <div class="table-responsive pt-3" id="<?php echo e($data['tables'][0]); ?>">
        <table class="table table-bordered" id="<?php echo e($data['tables'][0]); ?>">
            <thead>
                <tr>
                    <th class="text-center"><?php echo e(__('#')); ?></th>
                    <th class="text-center"><?php echo e(__('Kode')); ?></th>
                    <th class="text-center"><?php echo e(__('Nama')); ?></th>
                    <th class="text-center"><?php echo e(__('Satuan')); ?></th>
                    <th class="text-center"><?php echo e(__('Harga')); ?></th>
                    <th class="text-center"><?php echo e(__('Update Terakhir')); ?></th>
                    <th class="text-center"><?php echo e(__('Aksi')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if(isset($data['main']) && count($data['main']) > 0): ?>
                    <?php
                        $nomor = 1;
                    ?>
                    <?php $__currentLoopData = $data['main']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($nomor++); ?></td>
                            <td class="text-center"><?php echo e($value->kode); ?></td>
                            <td><?php echo e($value->nama); ?></td>
                            <td class="text-center"><?php echo e($value->satuan); ?></td>
                            <td class="text-end"><?php echo e('Rp. '.number_format($value->harga,2)); ?></td>
                            <td class="text-center"><?php echo e(date("d M Y",strtotime($value->updated_at))); ?></td>
                            <td class="text-center">
                                <div class="input-group-prepend">
                                  <button class="btn btn-sm btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="mdi mdi-pencil"></span></button>
                                      <div class="dropdown-menu">
                                        <a class="dropdown-item" href="#">Action</a>
                                        <a class="dropdown-item" href="#">Another action</a>
                                        <a class="dropdown-item" href="#">Something else here</a>
                                        <div role="separator" class="dropdown-divider"></div>
                                        <a class="dropdown-item" href="#">Separated link</a>
                                      </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                       <td colspan="6" class="text-center"><?php echo e(__('Data Tidak Ditemukan')); ?></td> 
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if(isset($data['main']) && count($data['main']) > 0): ?>
    <div class="card-footer d-flex align-items-center">
        <?php echo e($data['main']->links('vendor.pagination.rcs-paginator', ['tablename' => $data['tables'][0]])); ?>

    </div>
    <?php endif; ?>
</div><?php /**PATH C:\Users\LENOVO\Documents\GitHub\RABCountingSystem\resources\views/setting/table-harga-satuan-alat.blade.php ENDPATH**/ ?>