<?php

namespace App\Http\Controllers;

use App\Models\HargaSatuanPekerja;
use Illuminate\Http\Request;

class HargaSatuanPekerjaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(HargaSatuanPekerja $hargaSatuanPekerja)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(HargaSatuanPekerja $hargaSatuanPekerja)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, HargaSatuanPekerja $hargaSatuanPekerja)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(HargaSatuanPekerja $hargaSatuanPekerja)
    {
        //
    }
}
